#!/bin/sh
python3 /app/job.py
