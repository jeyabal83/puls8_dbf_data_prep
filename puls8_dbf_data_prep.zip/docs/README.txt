Place architecture and operational documentation here.
